% SegyMAT : A toolbox to read, write and manipulating SEG Y formatted files
% Version 1.00
