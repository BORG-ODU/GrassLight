% MATLAB/netcdf interface
%
